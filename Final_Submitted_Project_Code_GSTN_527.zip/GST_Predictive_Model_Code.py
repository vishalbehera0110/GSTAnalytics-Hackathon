# -*- coding: utf-8 -*-
"""
Created on Sun Oct  6 20:31:38 2024

@author: vishal
"""

#import the dataset
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import warnings
from sklearn.impute import SimpleImputer
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import seaborn as sns
from sklearn.model_selection import GridSearchCV
from lightgbm import LGBMClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,roc_curve


#Read the data
X_Train_Data_df = pd.read_csv(r"X_Train_Data_Input.csv")
Y_Train_Data_df =pd.read_csv(r"Y_Train_Data_Target.csv")


#Merging Target and Train Data into One
XY_Trn_Merge_df = pd.merge(X_Train_Data_df,Y_Train_Data_df,how='inner')

#Finding the Garbage Value (Datatype will be show as object)
XY_Trn_Merge_Final_df = XY_Trn_Merge_df.drop('ID',axis=1)

#Exploratory Data Analysis (EDA)

Null_Value_Percentages = (XY_Trn_Merge_Final_df.isnull().sum()/XY_Trn_Merge_Final_df.shape[0])*100

#Dropping Columns with most of the row values missing
XY_Trn_Drop_Column_df=XY_Trn_Merge_Final_df.drop(['Column9','Column14'], axis=1)


print("Descriptive Stats of DF after dropping Columns \n",XY_Trn_Drop_Column_df.describe())

## Define the imputer with the 'median' strategy

imputer = SimpleImputer(strategy='median')

# List of columns to apply the imputation
columns_to_impute_1 = ['Column3', 'Column4', 'Column5', 'Column6', 'Column8', 'Column15', 'Column0']

# Apply the imputer and create new columns with '_New' suffix
XY_Trn_Drop_Column_df[[f'{col}_New' for col in columns_to_impute_1]] = imputer.fit_transform(XY_Trn_Drop_Column_df[columns_to_impute_1])


XY_Trn_Drop_NullVals_df = XY_Trn_Drop_Column_df.dropna(axis=1)


# HISTOGRAMS AND BOX PLOT


# List of 19 columns to plot
columns = XY_Trn_Drop_NullVals_df.columns[:19]  # Modify this if you want specific columns

# Set up the figure for multiple plots
plt.figure(figsize=(12, 8 * len(columns)))  # Adjust the size according to the number of columns

# Loop through each column and plot histogram and box plot
for i, col in enumerate(columns):
    plt.subplot(len(columns), 2, 2*i + 1)  # Histogram on odd-numbered subplots
    sns.histplot(XY_Trn_Drop_NullVals_df[col], kde=False, bins=20, color='skyblue')  # Histogram
    plt.title(f'Histogram of {col}')
    
    plt.subplot(len(columns), 2, 2*i + 2)  # Box plot on even-numbered subplots
    sns.boxplot(x=XY_Trn_Drop_NullVals_df[col], color='lightgreen')  # Box plot
    plt.title(f'Box plot of {col}')

# Adjust layout
plt.tight_layout()

# Show the plots
plt.show()

#Outlier Removal using Isolation Forest and ensemblance Technique

# Scale the features
scaler = StandardScaler()
XY_Trn_Drop_NullVals_scaled_df = scaler.fit_transform(XY_Trn_Drop_NullVals_df)

# Instantiate the Isolation Forest model
iso_forest = IsolationForest(n_estimators=150, contamination=0.025, random_state=42)

# Fit the model and predict outliers
outliers = iso_forest.fit_predict(XY_Trn_Drop_NullVals_scaled_df)

# Remove the outliers
XY_Trn_cleaned_df = XY_Trn_Drop_NullVals_df[outliers == 1]


X_Y_Train_Data = XY_Trn_cleaned_df.copy()
#X_Y_Train_Data.describe()
#X_Y_Train_Data['target'].value_counts()
#X_Y_Train_Data.describe()

#X_Y_Train_Data['Column10'].describe()

X_Train = X_Y_Train_Data.drop(columns=['target'])
Y_Train = X_Y_Train_Data['target']


### REMOVING NOT REQUIRED COLUMNS

X_Train_New = X_Train.drop(columns=['Column20','Column19','Column21'])
Y_Train_New = Y_Train.copy()



####Test Data filling the missing values and removal of columns
#Read the data
X_Test_Data_df = pd.read_csv(r"X_Test_Data_Input.csv")
Y_Test_Data_df =pd.read_csv(r"Y_Test_Data_Target.csv")


#Merging Target and Train Data into One
XY_Tst_Merge_df=pd.merge(X_Test_Data_df,Y_Test_Data_df,how='inner')

#Finding the Garbage Value (Datatype will be show as object)
XY_Tst_Merge_Final_df=XY_Tst_Merge_df.drop('ID',axis=1)


#Dropping Columns with most of the row values missing
XY_Tst_Drop_Column_df = XY_Tst_Merge_Final_df.drop(['Column9','Column14'], axis=1)

# Define the imputer with the 'median' strategy
imputer = SimpleImputer(strategy='median')

# List of columns to apply the imputation
columns_to_impute = ['Column3', 'Column4', 'Column5', 'Column6', 'Column8', 'Column15', 'Column0']

# Apply the imputer and create new columns with '_New' suffix
XY_Tst_Drop_Column_df[[f'{col}_New' for col in columns_to_impute]] = imputer.fit_transform(XY_Tst_Drop_Column_df[columns_to_impute])



XY_Tst_Drop_NullVals_df = XY_Tst_Drop_Column_df.dropna(axis=1)


X_Test = XY_Tst_Drop_NullVals_df.drop(columns=['target'])
Y_Test = XY_Tst_Drop_NullVals_df['target']

X_Test_New = X_Test.drop(columns=['Column20','Column19','Column21'])
Y_Test_New = Y_Test.copy()


#Predictive Model LgBM   


# Handle class imbalance
#smote = SMOTE(random_state=42)
#X_train_res, y_train_res = smote.fit_resample(X_Train_New, Y_Train_New)

# Define parameter grid
param_grid_new = {
    'objective' : ['binary'],
    'metric': ['binary_logloss'],
    'num_leaves': [31],
    'learning_rate': [0.02],
    'min_data_in_leaf': [50],
    'feature_fraction': [0.8],
    'n_estimators': [100],
    'max_depth': [-1],
    'verbosity': [-1],
    'boosting_type': ['gbdt', 'dart', 'goss']
}

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# Grid search for hyperparameter tuning
lgbm_new = LGBMClassifier(class_weight={0: 1, 1: 2}) #class_weight={0: 1, 1: 2})
grid_search_new = GridSearchCV(estimator=lgbm_new, param_grid=param_grid_new, cv=cv, scoring='f1')
grid_search_new.fit(X_Train_New, Y_Train_New)
#best_model.fit(X_Train_New, Y_Train_New)


# Best model
best_model = grid_search_new.best_estimator_

# Make predictions For Train Data For Correlation Matrix
y_pred_train = best_model.predict(X_Train_New)
y_pred_proba_train = best_model.predict_proba(X_Train_New)[:, 1]


# Evaluate the training data model
accuracy = accuracy_score(Y_Train_New, y_pred_train)
precision = precision_score(Y_Train_New, y_pred_train)
recall = recall_score(Y_Train_New, y_pred_train)
f1 = f1_score(Y_Train_New, y_pred_train)
roc_auc = roc_auc_score(Y_Train_New, y_pred_proba_train)
conf_matrix = confusion_matrix(Y_Train_New, y_pred_train)

print("=================Training Data Evaluation Metrices==========")
print(f'Accuracy: {accuracy}')
print(f'Precision: {precision}')
print(f'Recall: {recall}')
print(f'F1 Score: {f1}')
print(f'ROC AUC: {roc_auc}')
print(f'Confusion Matrix:\n{conf_matrix}')
print('Classification Report:\n', classification_report(Y_Train_New, y_pred_train))
print("====================================================")

# Make predictions on test data
y_pred = best_model.predict(X_Test_New)
# Predict probabilities for the positive class (1)
y_pred_proba = best_model.predict_proba(X_Test_New)[:, 1]


# Evaluate the model
accuracy = accuracy_score(Y_Test_New, y_pred)
precision = precision_score(Y_Test_New, y_pred)
recall = recall_score(Y_Test_New, y_pred)
f1 = f1_score(Y_Test_New, y_pred)
roc_auc = roc_auc_score(Y_Test_New, y_pred_proba)
conf_matrix = confusion_matrix(Y_Test_New, y_pred)

print("\n=================Testing Data Evaluation Metrices==========")
print(f'Accuracy: {accuracy}')
print(f'Precision: {precision}')
print(f'Recall: {recall}')
print(f'F1 Score: {f1}')
print(f'ROC AUC: {roc_auc}')
print(f'Confusion Matrix:\n{conf_matrix}')
print('Classification Report:\n', classification_report(Y_Test, y_pred))
print("====================================================")




# Compute ROC curve and AUC score
fpr, tpr, thresholds = roc_curve(Y_Test_New, y_pred_proba)
roc_auc = roc_auc_score(Y_Test_New, y_pred_proba)

# Print the ROC AUC score
print(f'ROC AUC: {roc_auc:.2f}')

# Plot ROC curve
plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, color='blue', label=f'ROC Curve (AUC = {roc_auc:.2f})')
plt.plot([0, 1], [0, 1], color='gray', linestyle='--')  # Dashed diagonal line
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate (FPR)')
plt.ylabel('True Positive Rate (TPR)')
plt.title('Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc="lower right")
plt.grid(True)
plt.show()


