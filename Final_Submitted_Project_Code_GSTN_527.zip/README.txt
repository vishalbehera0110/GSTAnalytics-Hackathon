Instructions:

1. While running the script below Python Module should be Present/Installed:

-> pandas
-> numpy
-> matplotlib
-> sklearn
-> seaborn
-> lightgbm


2. Please add the following files in the same folder where the python file is present to run the entire script/model:

-> X_Test_Data_Input.csv
-> X_Train_Data_Input.csv
-> Y_Test_Data_Target.csv
-> Y_Train_Data_Target.csv